package com.example.insideoutproject.games;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import com.example.insideoutproject.R;

public class ChoiceChamberActivity extends Activity {

    private ScrollView choiceScrollView;
    private LinearLayout panelWelcome, panelScenario, panelFeedback, panelResults;
    private LinearLayout layoutChoiceSummary;

    private TextView txtProgress, txtScenarioTitle, txtScenarioDescription;
    private TextView txtFeedbackTitle, txtFeedback, txtResults;
    private TextView txtCompletionCount;
    private ProgressBar progressChoice;

    private Button btnStartChoice, btnChoiceA, btnChoiceB, btnChoiceC;
    private Button btnNextChoice, btnReplayChoice, btnExitChoice;

    private int currentScenario = 0;
    private final int[] choices = new int[5];

    private final Scenario[] scenarios = {
            new Scenario(
                    "The 2:17 AM Message",
                    "At 2:17 AM, your closest friend messages you: " +
                            "\"I need you to believe me. I did something terrible, " +
                            "but you can't tell anyone.\" Moments later, another " +
                            "friend sends you evidence suggesting someone may have " +
                            "been seriously hurt. Your friend hasn't explained anything yet.",
                    new String[] {
                            "A. Stand by my friend until I hear their side.",
                            "B. Contact the person who may have been hurt.",
                            "C. Investigate quietly before choosing a side."
                    },
                    new String[] {
                            "LOYALTY HAS A PRICE",
                            "You want to give someone you care about the chance to explain themselves. " +
                                    "That can be a powerful form of loyalty. But when someone may be in danger, " +
                                    "supporting a friend and protecting others can become competing responsibilities.",
                            "PROTECT THE PERSON AT RISK",
                            "You are prioritizing the possibility that someone needs help right now. " +
                                    "That instinct can matter more than preserving a friendship. The challenge " +
                                    "is acting on credible concerns without assuming you already know the whole story.",
                            "THE NEED FOR CERTAINTY",
                            "You want evidence before making a judgment. That can help prevent unfair accusations. " +
                                    "But sometimes waiting for certainty has consequences, especially when someone's safety " +
                                    "could be at risk."
                    }
            ),
            new Scenario(
                    "The Perfect Lie",
                    "You discover that people admire you for an achievement you never actually accomplished. " +
                            "Correcting the story could cost you a major opportunity. Nobody seems likely to discover " +
                            "the truth. You must decide what matters more before accepting the offer.",
                    new String[] {
                            "A. Tell the truth, even if I lose the opportunity.",
                            "B. Accept it and prove I deserve it.",
                            "C. Tell the people directly affected."
                    },
                    new String[] {
                            "INTEGRITY OVER ADVANTAGE",
                            "You are willing to risk a reward rather than build on a false impression. " +
                                    "Honesty can bring relief, even when it has a cost. The difficult part is accepting " +
                                    "that doing the right thing does not guarantee an easy outcome.",
                            "THE CHANCE TO PROVE YOURSELF",
                            "You may believe that future effort can make up for a dishonest beginning. " +
                                    "That drive to prove yourself can be motivating, but success alone may not repair " +
                                    "trust if other people made decisions based on something untrue.",
                            "HONESTY WITH A BOUNDARY",
                            "You are looking for a way to be truthful while limiting unnecessary harm. " +
                                    "That can be a thoughtful first step. Consider, though, who else may have been " +
                                    "affected by the misunderstanding and deserves to know."
                    }
            ),
            new Scenario(
                    "The Door You Cannot Reopen",
                    "You are offered a once-in-a-lifetime opportunity in another city. It could change " +
                            "your future, but accepting means leaving behind the people and routines that make " +
                            "you feel safe. You have to decide tonight, and there is no guarantee you can return.",
                    new String[] {
                            "A. Go. Growth requires risk.",
                            "B. Stay. The life I've built matters, too.",
                            "C. Find a way to go without losing my connections."
                    },
                    new String[] {
                            "CHOOSE THE UNKNOWN",
                            "You are willing to face uncertainty for the possibility of growth. " +
                                    "That can open unexpected doors, but bravery does not mean you have to ignore " +
                                    "your needs or pretend that leaving people behind will be easy.",
                            "HONOR WHAT YOU HAVE",
                            "You recognize that relationships, stability, and belonging have real value. " +
                                    "Staying is not automatically a failure of courage. It may help to ask whether " +
                                    "you are choosing the life you want or avoiding a future that frightens you.",
                            "BUILD A THIRD PATH",
                            "You are searching for a way to pursue change without treating your current life " +
                                    "as disposable. Compromise can be creative, though not every situation allows " +
                                    "you to keep everything. Decide which connections and values matter most."
                    }
            ),
            new Scenario(
                    "The Person Everyone Hates",
                    "Someone in your group is publicly blamed for ruining an important project. " +
                            "Everyone has stopped talking to them. You discover that their mistake was accidental " +
                            "and that the group ignored their earlier warnings. Speaking up could put your own " +
                            "place in the group at risk.",
                    new String[] {
                            "A. Defend them publicly, even if the group turns on me.",
                            "B. Speak to them privately and help them explain.",
                            "C. Present the overlooked evidence without taking sides."
                    },
                    new String[] {
                            "COURAGE IN PUBLIC",
                            "You are willing to risk your own standing to challenge what feels unfair. " +
                                    "Speaking up can help correct a group mistake. Think about how to make your case " +
                                    "clearly so the truth is heard rather than lost in an argument.",
                            "SUPPORT BEHIND THE SCENES",
                            "You want to help someone who may be isolated without immediately escalating " +
                                    "the conflict. Private support can be meaningful, but consider whether silence " +
                                    "allows a harmful public misunderstanding to continue.",
                            "LET THE EVIDENCE SPEAK",
                            "You want the group to reconsider the facts rather than turn the situation into " +
                                    "a personal battle. That can reduce defensiveness. Neutrality, however, does not " +
                                    "always have a neutral effect when someone is being treated unfairly."
                    }
            ),
            new Scenario(
                    "The Truth About You",
                    "Imagine a machine could reveal one uncomfortable truth about yourself with " +
                            "absolute accuracy. You cannot choose what it reveals, and once you see it, " +
                            "you cannot forget it. The truth might change how you see yourself, your relationships, " +
                            "or your future. Do you activate it?",
                    new String[] {
                            "A. Reveal the truth. I'd rather know than wonder.",
                            "B. Refuse. Some things are better left unknown.",
                            "C. Reveal it only if I can do something about it."
                    },
                    new String[] {
                            "CURIOSITY OVER COMFORT",
                            "You are drawn to clarity, even when the answer may be uncomfortable. " +
                                    "Self-knowledge can help you make thoughtful changes, but knowing something " +
                                    "does not mean you must define yourself by it.",
                            "PROTECT YOUR PEACE",
                            "You recognize that not every possible truth needs to be pursued. " +
                                    "Protecting your emotional space can be reasonable. It may also be worth asking " +
                                    "whether the choice comes from peace, fear, or a mixture of both.",
                            "KNOWLEDGE WITH PURPOSE",
                            "You want insight to lead somewhere useful, not simply leave you with a difficult " +
                                    "fact. That practical approach can help turn reflection into action. Still, " +
                                    "some truths matter even when they cannot be changed immediately."
                    }
            )
    };

    private static class Scenario {
        String title;
        String description;
        String[] options;
        String[] feedback;

        Scenario(String title, String description,
                 String[] options, String[] feedback) {
            this.title = title;
            this.description = description;
            this.options = options;
            this.feedback = feedback;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.choicechamberactivity);

        initializeViews();
        setListeners();
        resetChoices();
        showWelcome();
    }

    private void initializeViews() {
        choiceScrollView = findViewById(R.id.choiceScrollView);

        panelWelcome = findViewById(R.id.panelWelcome);
        panelScenario = findViewById(R.id.panelScenario);
        panelFeedback = findViewById(R.id.panelFeedback);
        panelResults = findViewById(R.id.panelResults);
        layoutChoiceSummary = findViewById(R.id.layoutChoiceSummary);

        txtProgress = findViewById(R.id.txtChoiceProgress);
        txtScenarioTitle = findViewById(R.id.txtScenarioTitle);
        txtScenarioDescription = findViewById(R.id.txtScenarioDescription);
        txtFeedbackTitle = findViewById(R.id.txtFeedbackTitle);
        txtFeedback = findViewById(R.id.txtFeedback);
        txtResults = findViewById(R.id.txtChoiceResults);
        txtCompletionCount = findViewById(R.id.txtCompletionCount);

        progressChoice = findViewById(R.id.progressChoice);

        btnStartChoice = findViewById(R.id.btnStartChoice);
        btnChoiceA = findViewById(R.id.btnChoiceA);
        btnChoiceB = findViewById(R.id.btnChoiceB);
        btnChoiceC = findViewById(R.id.btnChoiceC);
        btnNextChoice = findViewById(R.id.btnNextChoice);
        btnReplayChoice = findViewById(R.id.btnReplayChoice);
        btnExitChoice = findViewById(R.id.btnExitChoice);
    }

    private void setListeners() {
        btnStartChoice.setOnClickListener(v -> startGame());

        btnChoiceA.setOnClickListener(v -> selectAnswer(0));
        btnChoiceB.setOnClickListener(v -> selectAnswer(1));
        btnChoiceC.setOnClickListener(v -> selectAnswer(2));

        btnNextChoice.setOnClickListener(v -> {
            currentScenario++;

            if (currentScenario < scenarios.length) {
                showScenario();
            } else {
                showResults();
            }
        });

        btnReplayChoice.setOnClickListener(v -> {
            resetChoices();
            startGame();
        });

        btnExitChoice.setOnClickListener(v -> finish());
    }

    private void resetChoices() {
        currentScenario = 0;

        for (int i = 0; i < choices.length; i++) {
            choices[i] = -1;
        }
    }

    private void showWelcome() {
        panelWelcome.setVisibility(View.VISIBLE);
        panelScenario.setVisibility(View.GONE);
        panelResults.setVisibility(View.GONE);
        panelFeedback.setVisibility(View.GONE);
        scrollToTop();
    }

    private void startGame() {
        resetChoices();
        showScenario();
    }

    private void showScenario() {
        panelWelcome.setVisibility(View.GONE);
        panelResults.setVisibility(View.GONE);
        panelScenario.setVisibility(View.VISIBLE);
        panelFeedback.setVisibility(View.GONE);

        Scenario scenario = scenarios[currentScenario];

        txtProgress.setText(
                "SCENARIO " + (currentScenario + 1) +
                        " OF " + scenarios.length
        );

        progressChoice.setMax(scenarios.length);
        progressChoice.setProgress(currentScenario + 1);

        txtScenarioTitle.setText(scenario.title);
        txtScenarioDescription.setText(scenario.description);

        btnChoiceA.setText(scenario.options[0]);
        btnChoiceB.setText(scenario.options[1]);
        btnChoiceC.setText(scenario.options[2]);

        btnChoiceA.setEnabled(true);
        btnChoiceB.setEnabled(true);
        btnChoiceC.setEnabled(true);

        btnNextChoice.setText(
                currentScenario == scenarios.length - 1
                        ? "VIEW MY REFLECTIONS  →"
                        : "NEXT SCENARIO  →"
        );

        scrollToTop();
    }

    private void selectAnswer(int answer) {
        if (choices[currentScenario] != -1) {
            return;
        }

        choices[currentScenario] = answer;

        btnChoiceA.setEnabled(false);
        btnChoiceB.setEnabled(false);
        btnChoiceC.setEnabled(false);

        Scenario scenario = scenarios[currentScenario];
        int feedbackIndex = answer * 2;

        txtFeedbackTitle.setText(scenario.feedback[feedbackIndex]);
        txtFeedback.setText(scenario.feedback[feedbackIndex + 1]);

        panelFeedback.setVisibility(View.VISIBLE);

        btnNextChoice.setText(
                currentScenario == scenarios.length - 1
                        ? "VIEW MY REFLECTIONS  →"
                        : "NEXT SCENARIO  →"
        );

        choiceScrollView.post(() ->
                choiceScrollView.smoothScrollTo(
                        0, panelFeedback.getTop()
                )
        );
    }

    private void showResults() {
        panelWelcome.setVisibility(View.GONE);
        panelScenario.setVisibility(View.GONE);
        panelFeedback.setVisibility(View.GONE);
        panelResults.setVisibility(View.VISIBLE);

        txtCompletionCount.setText(
                scenarios.length + " / " + scenarios.length +
                        " SCENARIOS COMPLETE"
        );

        layoutChoiceSummary.removeAllViews();

        for (int i = 0; i < scenarios.length; i++) {
            addSummaryCard(i);
        }

        txtResults.setText(
                "You explored five difficult situations and made five decisions. " +
                        "Each choice involved a trade-off between values that can all matter: " +
                        "trust, honesty, security, empathy, and self-awareness.\n\n" +
                        "Look back at your answers. Which decision felt obvious? Which one " +
                        "made you hesitate? What information might change your mind?\n\n" +
                        "Your answers reflect how you approached these fictional situations. " +
                        "They are not a diagnosis or a fixed definition of your personality."
        );

        scrollToTop();
    }

    private void addSummaryCard(int index) {
        Scenario scenario = scenarios[index];
        int answer = choices[index];

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(14), dp(16), dp(14), dp(16));
        card.setBackground(createRoundedBackground(
                Color.rgb(18, 22, 39),
                Color.rgb(52, 58, 88),
                16
        ));

        LinearLayout.LayoutParams cardParams =
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                );
        cardParams.bottomMargin = dp(12);

        layoutChoiceSummary.addView(card, cardParams);

        TextView number = new TextView(this);
        number.setText(String.format("%02d", index + 1));
        number.setTextColor(Color.rgb(69, 230, 255));
        number.setTextSize(14);
        number.setTypeface(null, Typeface.BOLD);
        number.setGravity(Gravity.CENTER);
        number.setBackground(createRoundedBackground(
                Color.rgb(21, 53, 65),
                Color.TRANSPARENT,
                10
        ));

        LinearLayout.LayoutParams numberParams =
                new LinearLayout.LayoutParams(dp(42), dp(42));
        numberParams.rightMargin = dp(12);
        card.addView(number, numberParams);

        LinearLayout textColumn = new LinearLayout(this);
        textColumn.setOrientation(LinearLayout.VERTICAL);

        card.addView(textColumn, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
        ));

        TextView title = new TextView(this);
        title.setText(scenario.title);
        title.setTextColor(Color.rgb(245, 247, 255));
        title.setTextSize(15);
        title.setTypeface(null, Typeface.BOLD);
        textColumn.addView(title);

        TextView selectedChoice = new TextView(this);
        selectedChoice.setText(
                answer >= 0 ? scenario.options[answer] : "No answer selected"
        );
        selectedChoice.setTextColor(Color.rgb(69, 230, 255));
        selectedChoice.setTextSize(13);
        selectedChoice.setPadding(0, dp(6), 0, 0);
        textColumn.addView(selectedChoice);
    }

    private GradientDrawable createRoundedBackground(
            int fillColor, int strokeColor, int cornerDp) {

        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fillColor);
        drawable.setCornerRadius(dp(cornerDp));

        if (strokeColor != Color.TRANSPARENT) {
            drawable.setStroke(dp(1), strokeColor);
        }

        return drawable;
    }

    private int dp(float value) {
        return (int) (value *
                getResources().getDisplayMetrics().density + 0.5f);
    }

    private void scrollToTop() {
        choiceScrollView.post(() ->
                choiceScrollView.smoothScrollTo(0, 0)
        );
    }
}
