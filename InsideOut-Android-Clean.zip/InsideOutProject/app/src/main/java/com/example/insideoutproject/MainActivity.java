package com.example.insideoutproject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.insideoutproject.chat.ChatActivity;
import com.example.insideoutproject.games.GamesActivity;
import com.example.insideoutproject.quiz.QuizActivity;
import com.example.insideoutproject.R;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        View btnGames = findViewById(R.id.btnGames);
        View btnQuiz = findViewById(R.id.btnQuiz);
        View btnChat = findViewById(R.id.btnChat);

        btnGames.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, GamesActivity.class)));

        btnQuiz.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, QuizActivity.class)));

        btnChat.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, ChatActivity.class)));
    }
}
