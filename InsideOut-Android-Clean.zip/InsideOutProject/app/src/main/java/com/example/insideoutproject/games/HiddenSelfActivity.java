package com.example.insideoutproject.games;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import com.example.insideoutproject.R;

public class HiddenSelfActivity extends Activity {

    private ScrollView hiddenScrollView;
    private LinearLayout panelWelcome, panelCase, panelFeedback, panelResults;
    private LinearLayout layoutCaseSummary;

    private TextView txtCaseProgress, txtCaseTitle, txtCaseStory;
    private TextView txtClues, txtFeedbackTitle, txtFeedback;
    private TextView txtCaseResults, txtCaseCompletion;

    private ProgressBar progressCase;

    private Button btnStartCase, btnDeductionA, btnDeductionB;
    private Button btnDeductionC, btnNextCase, btnReplayCase, btnExitCase;

    private int currentCase = 0;
    private final int[] deductions = new int[5];

    private static class MysteryCase {
        String title;
        String story;
        String clues;
        String[] options;
        String[] feedback;

        MysteryCase(String title, String story, String clues,
                    String[] options, String[] feedback) {
            this.title = title;
            this.story = story;
            this.clues = clues;
            this.options = options;
            this.feedback = feedback;
        }
    }

    private final MysteryCase[] cases = {
            new MysteryCase(
                    "The Missing Trophy",
                    "A championship trophy vanishes from a locked school display room " +
                            "between 4:00 PM and 4:30 PM. Three students were nearby. " +
                            "The principal wants to blame someone before the school assembly.",
                    "CLUE 01  •  The display lock shows no sign of forced entry.\n\n" +
                            "CLUE 02  •  Maya had a key because she was organizing the assembly.\n\n" +
                            "CLUE 03  •  A security log shows the display room was opened at 4:12 PM, " +
                            "but the log does not identify who used the key.",
                    new String[] {
                            "A. Maya stole the trophy because she had a key.",
                            "B. Someone with authorized access may have moved it.",
                            "C. The security log proves the caretaker took it."
                    },
                    new String[] {
                            "ACCESS IS NOT PROOF",
                            "Maya had an opportunity, but having a key does not establish that she took the trophy. " +
                                    "The evidence supports asking who entered the room, not accusing the first person " +
                                    "who could have entered it.",
                            "FOLLOW THE EVIDENCE",
                            "This is the most cautious deduction supported by the clues. The room was opened " +
                                    "without visible forced entry, and someone had authorized access. The next step " +
                                    "would be to check the key records and ask whether the trophy was moved legitimately.",
                            "A LOG IS ONLY ONE CLUE",
                            "The log records an opening, not the identity of the person who opened the room. " +
                                    "It does not prove the caretaker was involved. A useful investigator separates " +
                                    "what a record shows from what they suspect it means."
                    }
            ),

            new MysteryCase(
                    "The Anonymous Letter",
                    "A student receives an anonymous letter warning them not to enter a science " +
                            "competition. The letter contains a detail about a private conversation held " +
                            "after class. Four classmates knew about the competition, and nobody admits " +
                            "writing the letter.",
                    "CLUE 01  •  The letter was made using paper available in every classroom.\n\n" +
                            "CLUE 02  •  The private conversation took place near an open corridor.\n\n" +
                            "CLUE 03  •  Two classmates heard part of the conversation from outside the room.",
                    new String[] {
                            "A. The person who knew the detail must be the writer.",
                            "B. One of the two classmates could have heard it.",
                            "C. The letter proves someone is jealous."
                    },
                    new String[] {
                            "KNOWING IS NOT WRITING",
                            "Knowing a private detail can make someone a person of interest, but it does not " +
                                    "prove they wrote the letter. The detail may have spread through several people. " +
                                    "Look for evidence connecting a person to the letter itself.",
                            "TRACE HOW INFORMATION TRAVELLED",
                            "This explanation fits the clues: the conversation could have been overheard. " +
                                    "But possibility is not proof. You would still need more evidence before deciding " +
                                    "who wrote the letter or why.",
                            "MOTIVES CAN MISLEAD",
                            "Jealousy is one possible motive, but the letter does not establish anyone's feelings. " +
                                    "An investigator should avoid turning an unsettling message into a story about " +
                                    "someone's personality without supporting evidence."
                    }
            ),

            new MysteryCase(
                    "The Vanishing Art Project",
                    "A student's final art project disappears from a shared studio the night before " +
                            "an exhibition. The studio was used by several students. One student, Arin, " +
                            "had argued with the artist earlier that day.",
                    "CLUE 01  •  The studio sign-out sheet shows several people stayed late.\n\n" +
                            "CLUE 02  •  Arin's argument was overheard, but nobody heard a threat.\n\n" +
                            "CLUE 03  •  A storage cart was found near the side exit, and its owner is unknown.",
                    new String[] {
                            "A. Arin took it because they had an argument.",
                            "B. Check who used the cart and who stayed late.",
                            "C. The project was probably thrown away by mistake."
                    },
                    new String[] {
                            "CONFLICT IS NOT EVIDENCE",
                            "The argument gives investigators a reason to ask questions, but it does not prove " +
                                    "Arin took anything. Assuming guilt because of a disagreement risks overlooking " +
                                    "other people and explanations.",
                            "BUILD A TIMELINE",
                            "This approach focuses on verifiable details: access, timing, and the cart. " +
                                    "A timeline could help establish what happened without deciding in advance " +
                                    "who must be responsible.",
                            "A PLAUSIBLE POSSIBILITY",
                            "Accidental removal is possible, but none of the clues confirms it. " +
                                    "The next step is to check storage areas, ask the people who used the studio, " +
                                    "and establish when the project was last seen."
                    }
            ),

            new MysteryCase(
                    "The Group Chat Screenshot",
                    "A private group chat screenshot appears on a public student forum. The screenshot " +
                            "shows only part of a conversation, making one student look cruel. The group " +
                            "claims someone leaked it deliberately.",
                    "CLUE 01  •  The screenshot begins in the middle of the conversation.\n\n" +
                            "CLUE 02  •  Several members had access to the original chat.\n\n" +
                            "CLUE 03  •  The image contains no sender name, timestamp, or metadata that " +
                            "identifies who captured it.",
                    new String[] {
                            "A. The student shown in the screenshot is the villain.",
                            "B. The screenshot alone cannot establish the full story.",
                            "C. The person who posted it must be in the group."
                    },
                    new String[] {
                            "CONTEXT CHANGES MEANING",
                            "A partial conversation can hide what came before or after it. The message may " +
                                    "still be hurtful, but the screenshot alone cannot explain the full exchange " +
                                    "or establish someone's overall character.",
                            "SEPARATE FACTS FROM ASSUMPTIONS",
                            "Correct. The screenshot is incomplete and does not identify who captured it. " +
                                    "You can acknowledge what is visible while withholding judgment about missing " +
                                    "context, intent, and the source of the leak.",
                            "THE SOURCE IS UNKNOWN",
                            "Someone outside the group could have received the screenshot, or a member could " +
                                    "have shared it. Without identifying evidence, the poster's membership remains " +
                                    "an open question."
                    }
            ),

            new MysteryCase(
                    "The Midnight Call",
                    "At 11:48 PM, a museum's motion sensor triggers an alert. The next morning, " +
                            "a small exhibit is found out of place, but nothing is missing. A guard reports " +
                            "hearing a door close. The museum manager suspects an attempted theft.",
                    "CLUE 01  •  The sensor can be triggered by movement near the exhibit.\n\n" +
                            "CLUE 02  •  A maintenance team had been working in the nearby corridor that day.\n\n" +
                            "CLUE 03  •  No missing objects, forced locks, or clear footprints are documented.",
                    new String[] {
                            "A. Someone definitely attempted to steal an object.",
                            "B. Maintenance activity could explain the disturbance.",
                            "C. The guard must have left a door unsecured."
                    },
                    new String[] {
                            "ALERT DOES NOT MEAN THEFT",
                            "The alarm and moved exhibit are worth investigating, but neither proves an attempted " +
                                    "theft. The absence of missing objects does not settle the case either. More records " +
                                    "and a careful timeline are needed.",
                            "TEST THE ALTERNATIVE",
                            "Maintenance is a plausible explanation because the team worked nearby. " +
                                    "Check work orders and speak with the team to see whether their activity matches " +
                                    "the time and location of the alert. A plausible explanation still needs verification.",
                            "AVOID ASSIGNING BLAME",
                            "The guard heard a door close, but that does not establish who used it or whether " +
                                    "it was unsecured. Check access logs and the door's condition before drawing " +
                                    "conclusions about responsibility."
                    }
            )
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hiddenselfactivity);

        initializeViews();
        setListeners();
        resetDeductions();
        showWelcome();
    }

    private void initializeViews() {
        hiddenScrollView = findViewById(R.id.hiddenScrollView);

        panelWelcome = findViewById(R.id.panelHiddenWelcome);
        panelCase = findViewById(R.id.panelCase);
        panelFeedback = findViewById(R.id.panelCaseFeedback);
        panelResults = findViewById(R.id.panelCaseResults);
        layoutCaseSummary = findViewById(R.id.layoutCaseSummary);

        txtCaseProgress = findViewById(R.id.txtCaseProgress);
        txtCaseTitle = findViewById(R.id.txtCaseTitle);
        txtCaseStory = findViewById(R.id.txtCaseStory);
        txtClues = findViewById(R.id.txtClues);
        txtFeedbackTitle = findViewById(R.id.txtCaseFeedbackTitle);
        txtFeedback = findViewById(R.id.txtCaseFeedback);
        txtCaseResults = findViewById(R.id.txtCaseResults);
        txtCaseCompletion = findViewById(R.id.txtCaseCompletion);

        progressCase = findViewById(R.id.progressCase);

        btnStartCase = findViewById(R.id.btnStartCase);
        btnDeductionA = findViewById(R.id.btnDeductionA);
        btnDeductionB = findViewById(R.id.btnDeductionB);
        btnDeductionC = findViewById(R.id.btnDeductionC);
        btnNextCase = findViewById(R.id.btnNextCase);
        btnReplayCase = findViewById(R.id.btnReplayCase);
        btnExitCase = findViewById(R.id.btnExitCase);
    }

    private void setListeners() {
        btnStartCase.setOnClickListener(v -> startGame());

        btnDeductionA.setOnClickListener(v -> chooseDeduction(0));
        btnDeductionB.setOnClickListener(v -> chooseDeduction(1));
        btnDeductionC.setOnClickListener(v -> chooseDeduction(2));

        btnNextCase.setOnClickListener(v -> {
            currentCase++;

            if (currentCase < cases.length) {
                showCase();
            } else {
                showResults();
            }
        });

        btnReplayCase.setOnClickListener(v -> {
            resetDeductions();
            startGame();
        });

        btnExitCase.setOnClickListener(v -> finish());
    }

    private void resetDeductions() {
        currentCase = 0;

        for (int i = 0; i < deductions.length; i++) {
            deductions[i] = -1;
        }
    }

    private void showWelcome() {
        panelWelcome.setVisibility(View.VISIBLE);
        panelCase.setVisibility(View.GONE);
        panelFeedback.setVisibility(View.GONE);
        panelResults.setVisibility(View.GONE);
        scrollToTop();
    }

    private void startGame() {
        resetDeductions();
        showCase();
    }

    private void showCase() {
        panelWelcome.setVisibility(View.GONE);
        panelCase.setVisibility(View.VISIBLE);
        panelFeedback.setVisibility(View.GONE);
        panelResults.setVisibility(View.GONE);

        MysteryCase mystery = cases[currentCase];

        txtCaseProgress.setText(
                "CASE " + (currentCase + 1) + " OF " + cases.length
        );

        progressCase.setMax(cases.length);
        progressCase.setProgress(currentCase + 1);

        txtCaseTitle.setText(mystery.title);
        txtCaseStory.setText(mystery.story);
        txtClues.setText(mystery.clues);

        btnDeductionA.setText(mystery.options[0]);
        btnDeductionB.setText(mystery.options[1]);
        btnDeductionC.setText(mystery.options[2]);

        btnDeductionA.setEnabled(true);
        btnDeductionB.setEnabled(true);
        btnDeductionC.setEnabled(true);

        btnNextCase.setText(
                currentCase == cases.length - 1
                        ? "VIEW CASE FILES  →"
                        : "NEXT CASE  →"
        );

        scrollToTop();
    }

    private void chooseDeduction(int answer) {
        if (deductions[currentCase] != -1) {
            return;
        }

        deductions[currentCase] = answer;

        btnDeductionA.setEnabled(false);
        btnDeductionB.setEnabled(false);
        btnDeductionC.setEnabled(false);

        MysteryCase mystery = cases[currentCase];
        int feedbackIndex = answer * 2;

        txtFeedbackTitle.setText(mystery.feedback[feedbackIndex]);
        txtFeedback.setText(mystery.feedback[feedbackIndex + 1]);

        panelFeedback.setVisibility(View.VISIBLE);

        btnNextCase.setText(
                currentCase == cases.length - 1
                        ? "VIEW CASE FILES  →"
                        : "NEXT CASE  →"
        );

        hiddenScrollView.post(() ->
                hiddenScrollView.smoothScrollTo(
                        0, panelFeedback.getBottom()
                )
        );
    }

    private void showResults() {
        panelWelcome.setVisibility(View.GONE);
        panelCase.setVisibility(View.GONE);
        panelFeedback.setVisibility(View.GONE);
        panelResults.setVisibility(View.VISIBLE);

        txtCaseCompletion.setText(
                cases.length + " / " + cases.length + " CASES INVESTIGATED"
        );

        layoutCaseSummary.removeAllViews();

        for (int i = 0; i < cases.length; i++) {
            addSummaryCard(i);
        }

        txtCaseResults.setText(
                "Every case contained clues, gaps, and tempting assumptions. " +
                        "A strong investigator separates what is known from what is merely possible.\n\n" +
                        "Think about the cases where you felt certain. Did the clues actually prove " +
                        "your conclusion, or did your mind fill in the missing details?\n\n" +
                        "There is no personality score here. This game is about practicing careful " +
                        "reasoning, considering alternative explanations, and staying curious when " +
                        "the evidence is incomplete."
        );

        scrollToTop();
    }

    private void addSummaryCard(int index) {
        MysteryCase mystery = cases[index];
        int answer = deductions[index];

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(14), dp(16), dp(14), dp(16));
        card.setBackground(createRoundedBackground(
                Color.rgb(18, 22, 39),
                Color.rgb(52, 58, 88),
                16
        ));

        LinearLayout.LayoutParams cardParams =
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                );
        cardParams.bottomMargin = dp(12);
        layoutCaseSummary.addView(card, cardParams);

        TextView number = new TextView(this);
        number.setText(String.format("%02d", index + 1));
        number.setTextColor(Color.rgb(69, 230, 255));
        number.setTextSize(14);
        number.setTypeface(null, Typeface.BOLD);
        number.setGravity(Gravity.CENTER);
        number.setBackground(createRoundedBackground(
                Color.rgb(21, 53, 65),
                Color.TRANSPARENT,
                10
        ));

        LinearLayout.LayoutParams numberParams =
                new LinearLayout.LayoutParams(dp(42), dp(42));
        numberParams.rightMargin = dp(12);
        card.addView(number, numberParams);

        LinearLayout textColumn = new LinearLayout(this);
        textColumn.setOrientation(LinearLayout.VERTICAL);

        card.addView(textColumn, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
        ));

        TextView title = new TextView(this);
        title.setText(mystery.title);
        title.setTextColor(Color.rgb(245, 247, 255));
        title.setTextSize(15);
        title.setTypeface(null, Typeface.BOLD);
        textColumn.addView(title);

        TextView selected = new TextView(this);
        selected.setText(
                answer >= 0
                        ? mystery.options[answer]
                        : "No deduction selected"
        );
        selected.setTextColor(Color.rgb(69, 230, 255));
        selected.setTextSize(13);
        selected.setPadding(0, dp(6), 0, 0);
        textColumn.addView(selected);
    }

    private GradientDrawable createRoundedBackground(
            int fillColor, int strokeColor, int cornerDp) {

        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fillColor);
        drawable.setCornerRadius(dp(cornerDp));

        if (strokeColor != Color.TRANSPARENT) {
            drawable.setStroke(dp(1), strokeColor);
        }

        return drawable;
    }

    private int dp(float value) {
        return (int) (value *
                getResources().getDisplayMetrics().density + 0.5f);
    }

    private void scrollToTop() {
        hiddenScrollView.post(() ->
                hiddenScrollView.smoothScrollTo(0, 0)
        );
    }
}
