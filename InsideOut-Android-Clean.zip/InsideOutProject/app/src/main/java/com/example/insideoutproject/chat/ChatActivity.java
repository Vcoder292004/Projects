package com.example.insideoutproject.chat;

import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.Tasks;
import com.example.insideoutproject.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.SetOptions;
import com.google.firebase.firestore.WriteBatch;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ChatActivity extends AppCompatActivity {

    private static final String TAG = "InsideOutChat";

    private static final String BACKEND_URL =
            "http://10.214.146.172:8000/chat";
    private LinearLayout chatMessages;
    private ScrollView chatScroll;
    private EditText edtMessage;
    private Button btnSend;

    private FirebaseAuth firebaseAuth;
    private FirebaseFirestore firestore;
    private FirebaseUser firebaseUser;

    private DocumentReference chatRef;

    private String userId;
    private String chatId;

    private boolean authReady = false;
    private boolean requestInProgress = false;
    private boolean greetingStarted = false;

    private final JSONArray history = new JSONArray();

    private final ExecutorService executor =
            Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        chatMessages = findViewById(R.id.chatMessages);
        chatScroll = findViewById(R.id.chatScroll);
        edtMessage = findViewById(R.id.edtMessage);
        btnSend = findViewById(R.id.btnSend);

        firebaseAuth = FirebaseAuth.getInstance();
        firestore = FirebaseFirestore.getInstance();

        btnSend.setEnabled(false);
        btnSend.setText("Connecting...");

        btnSend.setOnClickListener(v -> sendMessage());

        edtMessage.setOnEditorActionListener(
                (textView, actionId, event) -> {
                    sendMessage();
                    return true;
                }
        );

        signInAndPrepareChat();
    }

    // USER PROFILE

    private String getProfilePrefsName() {

        if (userId == null || userId.isEmpty()) {
            throw new IllegalStateException(
                    "User ID is not available"
            );
        }

        return "InsideOutProfile_" + userId;
    }

    private JSONObject getLocalQuizProfile()
            throws JSONException {

        android.content.SharedPreferences preferences =
                getSharedPreferences(
                        getProfilePrefsName(),
                        MODE_PRIVATE
                );

        String profileJson =
                preferences.getString("quiz_profile", "{}");

        return new JSONObject(profileJson);
    }

    // FIREBASE AUTHENTICATION

    private void signInAndPrepareChat() {

        Log.d(TAG, "Checking Firebase authentication");

        firebaseUser = firebaseAuth.getCurrentUser();

        if (firebaseUser == null) {

            Toast.makeText(
                    this,
                    "Please login to use your AI companion.",
                    Toast.LENGTH_LONG
            ).show();

            finish();
            return;
        }

        userId = firebaseUser.getUid();

        Log.d(TAG, "Authenticated user: " + userId);

        findLatestChat();
    }

    // FIND LATEST CHAT

    private void findLatestChat() {

        if (userId == null || userId.isEmpty()) {
            showError("User ID is missing.");
            return;
        }

        btnSend.setEnabled(false);
        btnSend.setText("Loading...");

        firestore.collection("users")
                .document(userId)
                .collection("chats")
                .orderBy(
                        "updatedAt",
                        Query.Direction.DESCENDING
                )
                .limit(1)
                .get()
                .addOnSuccessListener(querySnapshot -> {

                    if (isFinishing() || isDestroyed()) {
                        return;
                    }

                    if (querySnapshot.isEmpty()) {

                        createNewChat();

                    } else {

                        DocumentSnapshot latestChat =
                                querySnapshot.getDocuments().get(0);

                        chatRef = latestChat.getReference();
                        chatId = latestChat.getId();

                        Log.d(TAG, "Resuming chat: " + chatId);

                        loadMessagesFromFirestore();
                    }
                })
                .addOnFailureListener(e -> {

                    Log.e(TAG, "Could not find latest chat", e);

                    showError(
                            "Could not load chat history. Check internet and Firestore rules."
                    );
                });
    }

    // CREATE NEW CHAT

    private void createNewChat() {

        Log.d(TAG, "Creating a new chat");

        chatRef = firestore.collection("users")
                .document(userId)
                .collection("chats")
                .document();

        chatId = chatRef.getId();

        Map<String, Object> chatData = new HashMap<>();

        chatData.put("createdAt", FieldValue.serverTimestamp());
        chatData.put("updatedAt", FieldValue.serverTimestamp());
        chatData.put("lastMessageRole", "system");
        chatData.put("lastMessage", "");

        chatRef.set(chatData)
                .addOnSuccessListener(unused -> {

                    if (isFinishing() || isDestroyed()) {
                        return;
                    }

                    Log.d(TAG, "New chat created: " + chatId);

                    authReady = true;

                    saveQuizProfile();

                    startConversation();
                })
                .addOnFailureListener(e -> {

                    Log.e(TAG, "Chat creation failed", e);

                    showError(
                            "Could not create a new chat. Please try again."
                    );
                });
    }

    // LOAD PREVIOUS CHAT HISTORY

    private void loadMessagesFromFirestore() {

        if (chatRef == null) {
            showError("Chat reference is missing.");
            return;
        }

        btnSend.setEnabled(false);
        btnSend.setText("Loading history...");

        chatRef.collection("messages")
                .orderBy(
                        "createdAt",
                        Query.Direction.ASCENDING
                )
                .get()
                .addOnSuccessListener(querySnapshot -> {

                    if (isFinishing() || isDestroyed()) {
                        return;
                    }

                    synchronized (history) {
                        while (history.length() > 0) {
                            history.remove(0);
                        }
                    }

                    chatMessages.removeAllViews();

                    for (DocumentSnapshot document :
                            querySnapshot.getDocuments()) {

                        String role = document.getString("role");
                        String content = document.getString("content");

                        if (role == null || content == null) {
                            continue;
                        }

                        if (content.trim().isEmpty()) {
                            continue;
                        }

                        if (!role.equals("user")
                                && !role.equals("assistant")) {
                            continue;
                        }

                        addMessageToHistory(role, content);

                        addMessageBubble(
                                content,
                                role.equals("user")
                        );
                    }

                    authReady = true;

                    saveQuizProfile();

                    Log.d(
                            TAG,
                            "Loaded " + history.length() + " messages"
                    );

                    if (history.length() == 0) {
                        startConversation();
                    } else {
                        btnSend.setEnabled(true);
                        btnSend.setText("Send");
                        scrollToBottom();
                    }
                })
                .addOnFailureListener(e -> {

                    Log.e(TAG, "Message history loading failed", e);

                    showError(
                            "Could not load previous messages. Check Firestore permissions."
                    );
                });
    }

    // SAVE QUIZ PROFILE TO FIRESTORE

    private void saveQuizProfile() {

        if (userId == null) {
            return;
        }

        try {

            JSONObject profileObject = getLocalQuizProfile();

            Map<String, Object> profileData =
                    jsonObjectToMap(profileObject);

            profileData.put(
                    "updatedAt",
                    FieldValue.serverTimestamp()
            );

            firestore.collection("users")
                    .document(userId)
                    .collection("quiz_profile")
                    .document("current")
                    .set(profileData, SetOptions.merge())
                    .addOnSuccessListener(unused ->
                            Log.d(TAG, "Quiz profile saved")
                    )
                    .addOnFailureListener(e ->
                            Log.e(TAG, "Quiz profile save failed", e)
                    );

        } catch (Exception e) {

            Log.e(TAG, "Could not read local quiz profile", e);
        }
    }

    // JSON CONVERSION

    private Map<String, Object> jsonObjectToMap(
            JSONObject jsonObject
    ) throws JSONException {

        Map<String, Object> map = new HashMap<>();

        Iterator<String> keys = jsonObject.keys();

        while (keys.hasNext()) {

            String key = keys.next();

            map.put(
                    key,
                    convertJsonValue(jsonObject.get(key))
            );
        }

        return map;
    }

    private Object convertJsonValue(Object value)
            throws JSONException {

        if (value == JSONObject.NULL) {
            return null;
        }

        if (value instanceof JSONObject) {
            return jsonObjectToMap((JSONObject) value);
        }

        if (value instanceof JSONArray) {

            JSONArray array = (JSONArray) value;
            List<Object> list = new ArrayList<>();

            for (int i = 0; i < array.length(); i++) {
                list.add(convertJsonValue(array.get(i)));
            }

            return list;
        }

        return value;
    }

    // AUTOMATIC AI GREETING

    private void startConversation() {

        if (greetingStarted || !authReady || requestInProgress) {
            return;
        }

        greetingStarted = true;
        requestInProgress = true;

        btnSend.setEnabled(false);
        btnSend.setText("Starting...");

        Log.d(TAG, "Starting automatic AI greeting");

        executor.execute(() -> {

            try {

                String reply = requestAI();

                runOnUiThread(() -> {

                    if (isFinishing() || isDestroyed()) {
                        return;
                    }

                    addMessageToHistory("assistant", reply);
                    addMessageBubble(reply, false);
                    saveMessageToFirestore("assistant", reply);

                    requestInProgress = false;

                    btnSend.setEnabled(true);
                    btnSend.setText("Send");
                });

            } catch (Exception e) {

                Log.e(TAG, "Automatic greeting failed", e);

                runOnUiThread(() -> {

                    if (isFinishing() || isDestroyed()) {
                        return;
                    }

                    requestInProgress = false;

                    btnSend.setEnabled(true);
                    btnSend.setText("Send");

                    Toast.makeText(
                            ChatActivity.this,
                            "Could not start AI conversation: "
                                    + e.getMessage(),
                            Toast.LENGTH_LONG
                    ).show();
                });
            }
        });
    }

    // SEND USER MESSAGE

    private void sendMessage() {

        if (!authReady) {

            Toast.makeText(
                    this,
                    "Please wait while your chat connects.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        if (requestInProgress) {
            return;
        }

        String message = edtMessage.getText()
                .toString()
                .trim();

        if (message.isEmpty()) {
            return;
        }

        edtMessage.setText("");

        addMessageToHistory("user", message);
        addMessageBubble(message, true);
        saveMessageToFirestore("user", message);

        requestInProgress = true;

        btnSend.setEnabled(false);
        btnSend.setText("Thinking...");

        executor.execute(() -> {

            try {

                Log.d(TAG, "Sending user message to AI");

                String reply = requestAI();

                runOnUiThread(() -> {

                    if (isFinishing() || isDestroyed()) {
                        return;
                    }

                    addMessageToHistory("assistant", reply);
                    addMessageBubble(reply, false);
                    saveMessageToFirestore("assistant", reply);

                    requestInProgress = false;

                    btnSend.setEnabled(true);
                    btnSend.setText("Send");
                });

            } catch (Exception e) {

                Log.e(TAG, "AI request failed", e);

                runOnUiThread(() -> {

                    if (isFinishing() || isDestroyed()) {
                        return;
                    }

                    requestInProgress = false;

                    btnSend.setEnabled(true);
                    btnSend.setText("Send");

                    Toast.makeText(
                            ChatActivity.this,
                            "Could not get a reply: " + e.getMessage(),
                            Toast.LENGTH_LONG
                    ).show();
                });
            }
        });
    }

    // CONVERSATION HISTORY

    private void addMessageToHistory(
            String role,
            String content
    ) {

        synchronized (history) {

            JSONObject messageObject = new JSONObject();

            try {

                messageObject.put("role", role);
                messageObject.put("content", content);

                history.put(messageObject);

            } catch (JSONException e) {

                Log.e(TAG, "Could not add message to history", e);
            }
        }
    }

    // SEND PROFILE AND CHAT HISTORY TO BACKEND

    private String requestAI() throws Exception {

        JSONObject requestBody = new JSONObject();

        JSONObject profileObject = getLocalQuizProfile();

        JSONArray historyCopy = new JSONArray();

        synchronized (history) {

            for (int i = 0; i < history.length(); i++) {

                historyCopy.put(
                        new JSONObject(
                                history.getJSONObject(i).toString()
                        )
                );
            }
        }

        requestBody.put("profile", profileObject);
        requestBody.put("messages", historyCopy);
        requestBody.put("userId", userId);

        HttpURLConnection connection = null;

        try {

            URL url = new URL(BACKEND_URL);

            connection = (HttpURLConnection) url.openConnection();

            connection.setRequestMethod("POST");

            connection.setConnectTimeout(15000);
            connection.setReadTimeout(190000);

            connection.setDoOutput(true);

            connection.setRequestProperty(
                    "Content-Type",
                    "application/json; charset=UTF-8"
            );

            connection.setRequestProperty(
                    "Accept",
                    "application/json"
            );

            // FIREBASE AUTHENTICATION TOKEN

            FirebaseUser currentUser = firebaseAuth.getCurrentUser();

            if (currentUser == null) {
                throw new IllegalStateException(
                        "Firebase user is not authenticated. Please log in again."
                );
            }

            String idToken = Tasks.await(
                    currentUser.getIdToken(false)
            ).getToken();

            if (idToken == null || idToken.trim().isEmpty()) {
                throw new IllegalStateException(
                        "Could not retrieve Firebase authentication token."
                );
            }

            connection.setRequestProperty(
                    "Authorization",
                    "Bearer " + idToken
            );

            byte[] requestBytes =
                    requestBody.toString()
                            .getBytes(StandardCharsets.UTF_8);

            try (OutputStream outputStream =
                         connection.getOutputStream()) {

                outputStream.write(requestBytes);
                outputStream.flush();
            }

            int responseCode = connection.getResponseCode();

            InputStream inputStream;

            if (responseCode >= 200 && responseCode < 300) {
                inputStream = connection.getInputStream();
            } else {
                inputStream = connection.getErrorStream();
            }

            StringBuilder responseBuilder = new StringBuilder();

            if (inputStream != null) {

                try (BufferedReader reader =
                             new BufferedReader(
                                     new InputStreamReader(
                                             inputStream,
                                             StandardCharsets.UTF_8
                                     )
                             )) {

                    String line;

                    while ((line = reader.readLine()) != null) {
                        responseBuilder.append(line);
                    }
                }
            }

            String responseText = responseBuilder.toString();

            Log.d(TAG, "Backend HTTP response: " + responseCode);
            Log.d(TAG, "Backend response body: " + responseText);

            if (responseCode < 200 || responseCode >= 300) {

                throw new Exception(
                        "Backend returned HTTP "
                                + responseCode
                                + ": " + responseText
                );
            }

            JSONObject responseJson = new JSONObject(responseText);

            String reply =
                    responseJson.optString("reply", "").trim();

            if (reply.isEmpty()) {

                throw new Exception(
                        "Backend response did not contain a non-empty reply."
                );
            }

            return reply;

        } finally {

            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    // SAVE MESSAGE AND CHAT METADATA TO FIRESTORE

    private void saveMessageToFirestore(
            String role,
            String content
    ) {

        if (chatRef == null || userId == null) {

            Log.e(
                    TAG,
                    "Cannot save message: chat is not initialized."
            );

            return;
        }

        Map<String, Object> messageData = new HashMap<>();

        messageData.put("role", role);
        messageData.put("content", content);
        messageData.put("createdAt", FieldValue.serverTimestamp());

        Map<String, Object> updateData = new HashMap<>();

        updateData.put("updatedAt", FieldValue.serverTimestamp());
        updateData.put("lastMessageRole", role);
        updateData.put("lastMessage", content);

        DocumentReference messageRef =
                chatRef.collection("messages").document();

        WriteBatch batch = firestore.batch();

        batch.set(messageRef, messageData);
        batch.update(chatRef, updateData);

        batch.commit()
                .addOnSuccessListener(unused ->
                        Log.d(
                                TAG,
                                "Message and chat metadata saved: " + role
                        )
                )
                .addOnFailureListener(e ->
                        Log.e(TAG, "Message save failed: " + role, e)
                );
    }

    // DISPLAY CHAT BUBBLES

    private void addMessageBubble(
            String message,
            boolean isUser
    ) {

        TextView textView = new TextView(this);

        textView.setText(message);
        textView.setTextSize(15);
        textView.setTextColor(Color.WHITE);

        textView.setTypeface(
                Typeface.create("sans-serif", Typeface.NORMAL)
        );

        textView.setPadding(36, 24, 36, 24);

        textView.setMaxWidth(
                (int) (
                        getResources()
                                .getDisplayMetrics()
                                .widthPixels * 0.78
                )
        );

        GradientDrawable background = new GradientDrawable();

        background.setCornerRadius(36);

        if (isUser) {

            background.setColor(Color.parseColor("#7C3AED"));

        } else {

            background.setColor(Color.parseColor("#171C30"));

            background.setStroke(
                    2,
                    Color.parseColor("#343A58")
            );
        }

        textView.setBackground(background);

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        params.setMargins(12, 8, 12, 8);

        params.gravity = isUser
                ? Gravity.END
                : Gravity.START;

        textView.setLayoutParams(params);

        chatMessages.addView(textView);

        scrollToBottom();
    }

    private void scrollToBottom() {

        chatScroll.post(() ->
                chatScroll.fullScroll(View.FOCUS_DOWN)
        );
    }

    // ERROR HANDLING

    private void showError(String message) {

        runOnUiThread(() -> {

            if (isFinishing() || isDestroyed()) {
                return;
            }

            Toast.makeText(
                    ChatActivity.this,
                    message,
                    Toast.LENGTH_LONG
            ).show();

            authReady = false;

            btnSend.setEnabled(false);
            btnSend.setText("Connection error");
        });
    }

    // ACTIVITY CLEANUP

    @Override
    protected void onDestroy() {

        super.onDestroy();

        executor.shutdownNow();
    }
}
