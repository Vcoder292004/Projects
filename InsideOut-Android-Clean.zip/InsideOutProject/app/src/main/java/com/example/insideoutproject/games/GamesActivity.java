package com.example.insideoutproject.games;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import com.example.insideoutproject.R;

public class GamesActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_games);

        Button btnChoiceChamber = findViewById(R.id.btnChoiceChamber);
        Button btnHiddenSelf = findViewById(R.id.btnHiddenSelf);
        Button btnBackGames = findViewById(R.id.btnBackGames);

        btnChoiceChamber.setOnClickListener(v -> {
            Intent intent = new Intent(
                    GamesActivity.this,
                    ChoiceChamberActivity.class
            );
            startActivity(intent);
        });

        btnHiddenSelf.setOnClickListener(v -> {
            Intent intent = new Intent(
                    GamesActivity.this,
                    HiddenSelfActivity.class
            );
            startActivity(intent);
        });

        btnBackGames.setOnClickListener(v -> finish());
    }
}

