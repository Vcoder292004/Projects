
package com.example.insideoutproject.quiz;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.app.AlertDialog;
import android.util.Log;
import com.google.firebase.auth.FirebaseAuth;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

import com.example.insideoutproject.R;

public class QuizActivity extends AppCompatActivity {

    private TextView txtProgress, txtQuestion, txtHint;
    private EditText edtAnswer;
    private ProgressBar quizProgress;
    private Button btnBack, btnNext;

    private int currentQuestion = 0;

    private final String[] questions = {
            "What would you like us to call you?",
            "Tell us a little about yourself and your current life.",
            "What brought you to InsideOut? What would you like support with?",
            "What has been challenging for you lately?",
            "What would you like to understand or change about yourself?",
            "When you are having a difficult time, what kind of support helps you most?",
            "Is there anything else you would like your AI companion to know about you?"
    };

    private final String[] hints = {
            "Your preferred name or nickname.",
            "Share anything about your daily life, studies, work, interests, or responsibilities.",
            "Describe what you hope to get from your conversations.",
            "Share only what you feel comfortable discussing.",
            "Think about your feelings, habits, relationships, or personal goals.",
            "Describe what makes you feel heard, understood, or supported.",
            "This is optional. Share anything important that the other questions missed."
    };

    private final String[] answers = new String[questions.length];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.quizactivity);

        txtProgress = findViewById(R.id.txtProgress);
        txtQuestion = findViewById(R.id.txtQuestion);
        txtHint = findViewById(R.id.txtHint);
        edtAnswer = findViewById(R.id.edtAnswer);
        quizProgress = findViewById(R.id.quizProgress);
        btnBack = findViewById(R.id.btnBack);
        btnNext = findViewById(R.id.btnNext);

        // Load previously saved answers before displaying the quiz.
        loadQuizProfile();

        btnBack.setOnClickListener(v -> goBack());
        btnNext.setOnClickListener(v -> goNext());

        showQuestion();
    }

    // LOAD PREVIOUSLY SAVED QUIZ ANSWERS
    private String getProfilePrefsName() {
        String userId = FirebaseAuth.getInstance()
                .getCurrentUser()
                .getUid();

        return "InsideOutProfile_" + userId;
    }

    private void loadQuizProfile() {

        if (FirebaseAuth.getInstance().getCurrentUser() == null) {
            return;
        }

        SharedPreferences preferences =
                getSharedPreferences(getProfilePrefsName(), MODE_PRIVATE);

        String json = preferences.getString("quiz_profile", "{}");

        try {
            JSONObject profile = new JSONObject(json);

            for (int i = 0; i < questions.length; i++) {
                answers[i] = profile.optString(questions[i], "");
            }

        } catch (Exception e) {
            Log.e("QUIZ_DEBUG", "Profile loading failed", e);
        }
    }
    private void showQuestion() {

        txtProgress.setText(
                "QUESTION " + (currentQuestion + 1)
                        + " OF " + questions.length
        );

        quizProgress.setMax(questions.length);
        quizProgress.setProgress(currentQuestion + 1);

        txtQuestion.setText(questions[currentQuestion]);
        txtHint.setText(hints[currentQuestion]);

        // Display the previously saved answer.
        edtAnswer.setText(
                answers[currentQuestion] == null
                        ? ""
                        : answers[currentQuestion]
        );

        edtAnswer.setHint("Write your answer here...");

        btnBack.setEnabled(currentQuestion > 0);
        btnBack.setAlpha(currentQuestion > 0 ? 1f : 0.5f);

        btnNext.setText(
                currentQuestion == questions.length - 1
                        ? "Finish"
                        : "Next"
        );

        edtAnswer.setInputType(
                InputType.TYPE_CLASS_TEXT
                        | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
                        | InputType.TYPE_TEXT_FLAG_MULTI_LINE
        );
    }

    // SAVE THE CURRENT QUESTION ANSWER
    private void saveCurrentAnswer() {

        String answer = edtAnswer.getText().toString().trim();

        answers[currentQuestion] = answer;

        Log.d(
                "QUIZ_DEBUG",
                "Question " + (currentQuestion + 1)
                        + " answer saved: " + answer
        );
    }

    private void goNext() {

        saveCurrentAnswer();

        // Save progress locally.
        saveQuizProfile();

        if (currentQuestion < questions.length - 1) {

            currentQuestion++;

            showQuestion();

        } else {

            showReview();
        }
    }

    private void goBack() {

        saveCurrentAnswer();

        saveQuizProfile();

        if (currentQuestion > 0) {

            currentQuestion--;

            showQuestion();
        }
    }

    // SAVE ALL QUIZ ANSWERS TO SHAREDPREFERENCES
    private void saveQuizProfile() {

        try {

            JSONObject profile = new JSONObject();

            for (int i = 0; i < questions.length; i++) {

                String answer = answers[i] == null
                        ? ""
                        : answers[i];

                profile.put(questions[i], answer);
            }

            SharedPreferences preferences =
                    getSharedPreferences(
                            getProfilePrefsName(),
                            MODE_PRIVATE
                    );
            preferences.edit()
                    .putString("quiz_profile", profile.toString())
                    .apply();

            Log.d(
                    "QUIZ_DEBUG",
                    "Quiz profile saved: " + profile
            );

        } catch (Exception e) {

            Log.e("QUIZ_DEBUG", "Error saving quiz profile", e);

            Toast.makeText(
                    this,
                    "Could not save your profile.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    // SHOW FINAL REVIEW
    private void showReview() {

        StringBuilder review = new StringBuilder();

        for (int i = 0; i < questions.length; i++) {

            review.append(i + 1)
                    .append(". ")
                    .append(questions[i])
                    .append("\n")
                    .append(
                            answers[i] == null
                                    || answers[i].isEmpty()
                                    ? "Not answered"
                                    : answers[i]
                    )
                    .append("\n\n");
        }

        new AlertDialog.Builder(this)

                .setTitle("Your personal profile")

                .setMessage(review.toString())

                .setNegativeButton("Go Back", (dialog, which) -> {

                    currentQuestion = questions.length - 1;

                    showQuestion();
                })

                .setPositiveButton("Done", (dialog, which) -> {

                    saveQuizProfile();

                    Toast.makeText(
                            this,
                            "Your profile has been saved on this device.",
                            Toast.LENGTH_SHORT
                    ).show();

                    finish();
                })

                .show();
    }

    @Override
    protected void onPause() {

        if (edtAnswer != null) {

            saveCurrentAnswer();

            saveQuizProfile();
        }

        super.onPause();
    }
}
